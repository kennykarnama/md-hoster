# Howdy :D

Hi, My name is Kenny.

I am a software engineer based in Indonesia.

This is my personal sites.

I will share everything I can share to you.

My CV will be here too :D


## Index

[my cv](./cv.md)